package com.yasin.yconverter
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.yasin.yconverter.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(val inputText:String="",val selectedModeId:String="base64_std",val operation:Operation=Operation.ENCODE,val outputText:String="",val isProcessing:Boolean=false,val errorMessage:String?=null,val canCopy:Boolean=false)
class MainViewModel:ViewModel(){ private val _state=MutableStateFlow(MainUiState());val state:StateFlow<MainUiState> = _state.asStateFlow();fun setInput(v:String){_state.value=_state.value.copy(inputText=v,errorMessage=null)};fun setMode(id:String){_state.value=_state.value.copy(selectedModeId=id,outputText="",canCopy=false,errorMessage=null)};fun setOperation(op:Operation){_state.value=_state.value.copy(operation=op,outputText="",canCopy=false,errorMessage=null)};fun clear(){_state.value=MainUiState(selectedModeId=_state.value.selectedModeId)};fun convert(){val s=_state.value;if(s.inputText.length>1_000_000){_state.value=s.copy(errorMessage="متن بیش از حد بزرگ است (حد V1: یک میلیون کاراکتر).") ;return};val c=ConverterRegistry.byId(s.selectedModeId)?:return;_state.value=s.copy(isProcessing=true,errorMessage=null);viewModelScope.launch{val r=withContext(Dispatchers.Default){if(s.operation==Operation.ENCODE)c.encode(s.inputText) else c.decode(s.inputText)};_state.value=when(r){is ConversionResult.Success->s.copy(outputText=r.value,isProcessing=false,canCopy=true,errorMessage=null);is ConversionResult.Error->s.copy(outputText="",isProcessing=false,canCopy=false,errorMessage=r.message)}}}}
