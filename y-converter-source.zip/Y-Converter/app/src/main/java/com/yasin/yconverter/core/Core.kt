package com.yasin.yconverter.core

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Base64

sealed interface ConversionResult {
    data class Success(val value: String): ConversionResult
    data class Error(val message: String): ConversionResult
}

enum class Operation { ENCODE, DECODE }
enum class Category(val fa:String) { BYTES("عدد / بایت"), BASE("Base Encoding"), CHARACTER("کاراکتر"), UTF("Unicode / UTF"), MORSE("Morse"), ERROR_CORRECTION("تصحیح خطا"), MEDICAL("پزشکی") }

data class ConverterMeta(val id:String,val fa:String,val en:String,val category:Category,val supportsEncode:Boolean=true,val supportsDecode:Boolean=true)
interface Converter { val meta: ConverterMeta; fun encode(input:String):ConversionResult; fun decode(input:String):ConversionResult }

object HexUtil {
    fun encode(bytes:ByteArray)=bytes.joinToString(" "){"%02X".format(it.toInt() and 0xff)}
    fun decode(text:String):ByteArray? {
        val clean=text.replace("0x","",true).replace(Regex("[\\s:_-]+"),"")
        if(clean.length%2!=0 || !clean.matches(Regex("[0-9A-Fa-f]*"))) return null
        return ByteArray(clean.length/2){ i -> clean.substring(i*2,i*2+2).toInt(16).toByte() }
    }
}

class ByteRadixConverter(private val radix:Int, private val width:Int, override val meta:ConverterMeta):Converter {
    override fun encode(input:String)=ConversionResult.Success(input.toByteArray(Charsets.UTF_8).joinToString(" "){(it.toInt() and 0xff).toString(radix).uppercase().padStart(width,'0')})
    override fun decode(input:String):ConversionResult {
        val tokens=input.trim().split(Regex("[\\s,]+" )).filter{it.isNotEmpty()}
        if(tokens.isEmpty() && input.isNotEmpty()) return ConversionResult.Error("ورودی معتبر نیست.")
        val bytes=ByteArray(tokens.size)
        for((i,t) in tokens.withIndex()) { val v=t.toIntOrNull(radix) ?: return ConversionResult.Error("بلوک نامعتبر: $t"); if(v !in 0..255) return ConversionResult.Error("مقدار بایت خارج از محدوده: $t"); bytes[i]=v.toByte() }
        return strictUtf8(bytes)
    }
    private fun strictUtf8(b:ByteArray):ConversionResult = try {
        val d=Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
        ConversionResult.Success(d.decode(ByteBuffer.wrap(b)).toString())
    } catch(_:Exception){ConversionResult.Error("دنباله بایت UTF-8 معتبر نیست.")}
}

object Base32Codec {
    private const val A="ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    fun enc(data:ByteArray):String { if(data.isEmpty()) return ""; val sb=StringBuilder(); var buffer=0; var bits=0; for(b in data){ buffer=(buffer shl 8) or (b.toInt() and 255); bits+=8; while(bits>=5){bits-=5; sb.append(A[(buffer shr bits) and 31])} }; if(bits>0) sb.append(A[(buffer shl (5-bits)) and 31]); while(sb.length%8!=0) sb.append('='); return sb.toString() }
    fun dec(s:String):ByteArray? { val x=s.trim().replace(Regex("\\s+"),"").uppercase(); if(x.isEmpty()) return byteArrayOf(); val core=x.trimEnd('='); if(core.any{A.indexOf(it)<0}) return null; val out=ByteArrayOutputStream(); var buffer=0; var bits=0; for(c in core){buffer=(buffer shl 5) or A.indexOf(c);bits+=5;if(bits>=8){bits-=8;out.write((buffer shr bits) and 255)}}; return out.toByteArray() }
}
class Base32Converter:Converter { override val meta=ConverterMeta("base32","بیس۳۲","Base32",Category.BASE); override fun encode(input:String)=ConversionResult.Success(Base32Codec.enc(input.toByteArray())); override fun decode(input:String)=decodeBytes(Base32Codec.dec(input)) }

class Base64Converter(private val url:Boolean, private val padding:Boolean, override val meta:ConverterMeta):Converter {
    override fun encode(input:String):ConversionResult { var e=if(url) Base64.getUrlEncoder() else Base64.getEncoder(); if(!padding)e=e.withoutPadding(); return ConversionResult.Success(e.encodeToString(input.toByteArray())) }
    override fun decode(input:String):ConversionResult = try { val clean=input.trim(); val normalized=if(clean.length%4==0) clean else clean+"=".repeat((4-clean.length%4)%4); decodeBytes((if(url) Base64.getUrlDecoder() else Base64.getDecoder()).decode(normalized)) } catch(_:Exception){ ConversionResult.Error("Base64 نامعتبر است.") }
}

object Ascii85 {
    fun encode(data:ByteArray):String { val sb=StringBuilder(); var i=0; while(i<data.size){ val n=minOf(4,data.size-i); var v=0L; repeat(4){v=v shl 8; if(it<n)v=v or (data[i+it].toLong() and 255)}; if(n==4 && v==0L) sb.append('z') else { val a=CharArray(5); for(k in 4 downTo 0){a[k]=((v%85)+33).toInt().toChar();v/=85}; sb.append(a.concatToString().substring(0,n+1)) }; i+=n }; return sb.toString() }
    fun decode(text:String):ByteArray? { val s=text.replace(Regex("\\s+"),""); val out=ByteArrayOutputStream(); var group=StringBuilder(); fun flush(last:Boolean):Boolean { if(group.isEmpty())return true; val orig=group.length; if(orig==1)return false; while(group.length<5)group.append('u'); var v=0L; for(c in group){ if(c.code !in 33..117)return false; v=v*85+(c.code-33) }; val b=byteArrayOf((v shr 24).toByte(),(v shr 16).toByte(),(v shr 8).toByte(),v.toByte()); out.write(b,0,if(last)orig-1 else 4);group=StringBuilder();return true }; for(c in s){ if(c=='z'){if(group.isNotEmpty())return null;out.write(byteArrayOf(0,0,0,0));continue};group.append(c);if(group.length==5&&!flush(false))return null }; if(!flush(true))return null; return out.toByteArray() }
}
class Ascii85Converter:Converter { override val meta=ConverterMeta("ascii85","بیس۸۵ / ASCII85","Base85 / ASCII85",Category.BASE); override fun encode(input:String)=ConversionResult.Success(Ascii85.encode(input.toByteArray())); override fun decode(input:String)=decodeBytes(Ascii85.decode(input)) }

class AsciiConverter:Converter { override val meta=ConverterMeta("ascii","آسکی","ASCII",Category.CHARACTER); override fun encode(input:String):ConversionResult { if(input.any{it.code>127})return ConversionResult.Error("ASCII فقط کاراکترهای 0 تا 127 را پشتیبانی می‌کند؛ برای فارسی از Unicode/UTF استفاده کنید."); return ConversionResult.Success(input.map{it.code}.joinToString(" "))}; override fun decode(input:String):ConversionResult { val t=input.trim().split(Regex("[\\s,]+" )).filter{it.isNotEmpty()}; val sb=StringBuilder(); for(x in t){val n=x.toIntOrNull()?:return ConversionResult.Error("کد ASCII نامعتبر: $x");if(n !in 0..127)return ConversionResult.Error("کد ASCII خارج از محدوده: $x");sb.append(n.toChar())};return ConversionResult.Success(sb.toString())} }
class UnicodeConverter:Converter { override val meta=ConverterMeta("unicode","یونیکد","Unicode code point",Category.CHARACTER); override fun encode(input:String):ConversionResult { val out=mutableListOf<String>(); var i=0; while(i<input.length){ val cp=input.codePointAt(i); out += "U+"+cp.toString(16).uppercase().padStart(if(cp<=0xffff)4 else 6,'0'); i+=Character.charCount(cp)}; return ConversionResult.Success(out.joinToString(" ")) }; override fun decode(input:String):ConversionResult { val sb=StringBuilder(); for(t in input.trim().split(Regex("[\\s,]+" )).filter{it.isNotEmpty()}){val s=t.removePrefix("U+").removePrefix("u+");val cp=s.toIntOrNull(16)?:return ConversionResult.Error("Unicode نامعتبر: $t");if(!Character.isValidCodePoint(cp)||cp in 0xD800..0xDFFF)return ConversionResult.Error("Code point نامعتبر: $t");sb.appendCodePoint(cp)};return ConversionResult.Success(sb.toString())} }

enum class UtfKind { UTF8, UTF16, UTF16BE, UTF16LE, UTF32BE, UTF32LE, UTF7 }
class UtfConverter(private val kind:UtfKind, override val meta:ConverterMeta):Converter {
    override fun encode(input:String):ConversionResult = ConversionResult.Success(HexUtil.encode(when(kind){ UtfKind.UTF8->input.toByteArray(Charsets.UTF_8); UtfKind.UTF16->input.toByteArray(Charsets.UTF_16); UtfKind.UTF16BE->input.toByteArray(Charsets.UTF_16BE); UtfKind.UTF16LE->input.toByteArray(Charsets.UTF_16LE); UtfKind.UTF32BE->utf32(input,ByteOrder.BIG_ENDIAN); UtfKind.UTF32LE->utf32(input,ByteOrder.LITTLE_ENDIAN); UtfKind.UTF7->Utf7.encode(input)}))
    override fun decode(input:String):ConversionResult { val b=HexUtil.decode(input)?:return ConversionResult.Error("HEX bytes نامعتبر است."); return try { when(kind){ UtfKind.UTF32BE->Utf32.decode(b,ByteOrder.BIG_ENDIAN); UtfKind.UTF32LE->Utf32.decode(b,ByteOrder.LITTLE_ENDIAN); UtfKind.UTF7->ConversionResult.Success(Utf7.decode(b)); else->{val cs=when(kind){UtfKind.UTF8->Charsets.UTF_8;UtfKind.UTF16->Charsets.UTF_16;UtfKind.UTF16BE->Charsets.UTF_16BE;UtfKind.UTF16LE->Charsets.UTF_16LE;else->Charsets.UTF_8}; val d=cs.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);ConversionResult.Success(d.decode(ByteBuffer.wrap(b)).toString())} } } catch(_:Exception){ConversionResult.Error("دنباله UTF نامعتبر یا ناقص است.")} }
    private fun utf32(s:String,o:ByteOrder):ByteArray { val out=ByteArrayOutputStream(); var i=0; while(i<s.length){val cp=s.codePointAt(i);val bb=ByteBuffer.allocate(4).order(o).putInt(cp).array();out.write(bb);i+=Character.charCount(cp)};return out.toByteArray() }
}
object Utf32 { fun decode(b:ByteArray,o:ByteOrder):ConversionResult {if(b.size%4!=0)return ConversionResult.Error("UTF-32 باید مضربی از 4 بایت باشد.");val sb=StringBuilder();val bb=ByteBuffer.wrap(b).order(o);while(bb.remaining()>=4){val cp=bb.int;if(!Character.isValidCodePoint(cp)||cp in 0xD800..0xDFFF)return ConversionResult.Error("UTF-32 دارای code point نامعتبر است.");sb.appendCodePoint(cp)};return ConversionResult.Success(sb.toString())} }

/* RFC 2152 UTF-7, legacy. Direct set intentionally conservative; non-direct chars are shifted Base64 UTF-16BE. */
object Utf7 {
    private fun direct(c:Char)=c.code in 0x20..0x7E && c!='+'
    fun encode(s:String):ByteArray { val out=StringBuilder(); val shifted=StringBuilder(); fun flush(){if(shifted.isNotEmpty()){val raw=shifted.toString().toByteArray(Charsets.UTF_16BE);out.append('+').append(Base64.getEncoder().withoutPadding().encodeToString(raw).replace('/' , '/')).append('-');shifted.clear()}}; for(c in s){ if(c=='+'){flush();out.append("+-")} else if(direct(c)){flush();out.append(c)} else shifted.append(c)};flush();return out.toString().toByteArray(Charsets.US_ASCII) }
    fun decode(b:ByteArray):String { val s=b.toString(Charsets.US_ASCII); val out=StringBuilder(); var i=0; while(i<s.length){if(s[i]!='+'){out.append(s[i++]);continue}; val end=s.indexOf('-',i+1); if(end<0)throw IllegalArgumentException(); if(end==i+1){out.append('+');i=end+1;continue}; val token=s.substring(i+1,end); val padded=token+"=".repeat((4-token.length%4)%4); val raw=Base64.getDecoder().decode(padded); if(raw.size%2!=0)throw IllegalArgumentException(); out.append(raw.toString(Charsets.UTF_16BE));i=end+1};return out.toString() }
}

/* RFC 3501 modified UTF-7 mailbox form: '&' shift, ',' instead of '/', no padding. */
class ImapModifiedUtf7Converter:Converter {
    override val meta=ConverterMeta("imap_mod_utf7","IMAP Modified UTF‑7","IMAP Modified UTF-7",Category.BASE)
    override fun encode(input:String):ConversionResult {
        val out=StringBuilder(); val buf=StringBuilder()
        fun flush(){ if(buf.isNotEmpty()){ val b64=Base64.getEncoder().withoutPadding().encodeToString(buf.toString().toByteArray(Charsets.UTF_16BE)).replace('/',','); out.append('&').append(b64).append('-'); buf.clear() } }
        for(c in input){ if(c.code in 0x20..0x7e && c!='&'){flush();out.append(c)} else if(c=='&'){flush();out.append("&-")} else buf.append(c) }
        flush(); return ConversionResult.Success(out.toString())
    }
    override fun decode(input:String):ConversionResult {
        return try {
            val out=StringBuilder(); var i=0
            while(i<input.length){
                if(input[i]!='&'){ out.append(input[i++]); continue }
                val e=input.indexOf('-',i+1)
                if(e<0) return ConversionResult.Error("IMAP Modified UTF-7 نامعتبر است.")
                if(e==i+1){ out.append('&'); i=e+1; continue }
                val tok=input.substring(i+1,e).replace(',','/'); val pad=tok+"=".repeat((4-tok.length%4)%4)
                val raw=Base64.getDecoder().decode(pad)
                if(raw.size%2!=0) return ConversionResult.Error("دنباله Modified UTF-7 نامعتبر است.")
                out.append(raw.toString(Charsets.UTF_16BE)); i=e+1
            }
            ConversionResult.Success(out.toString())
        } catch(_:Exception){ ConversionResult.Error("IMAP Modified UTF-7 نامعتبر است.") }
    }
}

class MorseConverter(override val meta:ConverterMeta, private val map:Map<String,String>):Converter { private val reverse=map.entries.associate{it.value to it.key}; override fun encode(input:String):ConversionResult {val words=input.trim().split(Regex("\\s+"));val out=mutableListOf<String>();for(w in words){val parts=mutableListOf<String>();var i=0;while(i<w.length){val cp=w.codePointAt(i);val ch=String(Character.toChars(cp)).uppercase();val m=map[ch]?:return ConversionResult.Error("کاراکتر پشتیبانی‌نشده در ${meta.en}: $ch");parts+=m;i+=Character.charCount(cp)};out+=parts.joinToString(" ")};return ConversionResult.Success(out.joinToString(" / "))}; override fun decode(input:String):ConversionResult {val words=input.trim().split(Regex("\\s*/\\s*"));val out=mutableListOf<String>();for(w in words){val sb=StringBuilder();for(t in w.trim().split(Regex("\\s+")).filter{it.isNotEmpty()}){sb.append(reverse[t]?:return ConversionResult.Error("نماد Morse ناشناخته: $t"))};out+=sb.toString()};return ConversionResult.Success(out.joinToString(" "))} }
object MorseTables {
    val INTERNATIONAL:Map<String,String> = mapOf(
        "A" to ".-","B" to "-...","C" to "-.-.","D" to "-..","E" to ".","F" to "..-.","G" to "--.","H" to "....","I" to "..","J" to ".---","K" to "-.-","L" to ".-..","M" to "--","N" to "-.","O" to "---","P" to ".--.","Q" to "--.-","R" to ".-.","S" to "...","T" to "-","U" to "..-","V" to "...-","W" to ".--","X" to "-..-","Y" to "-.--","Z" to "--..",
        "0" to "-----","1" to ".----","2" to "..---","3" to "...--","4" to "....-","5" to ".....","6" to "-....","7" to "--...","8" to "---..","9" to "----.",
        "." to ".-.-.-","," to "--..--","?" to "..--..","'" to ".----.","!" to "-.-.--","/" to "-..-.","(" to "-.--.",")" to "-.--.-","&" to ".-...",":" to "---...",";" to "-.-.-.","=" to "-...-","+" to ".-.-.","-" to "-....-","_" to "..--.-","\"" to ".-..-.","@" to ".--.-."
    )
    // Persian adaptation table. Duplicate patterns exist in documented practice (e.g. ذ/ز and ژ/ق), so decoding such patterns is inherently ambiguous.
    val PERSIAN=mapOf(
        "ا" to ".-","ب" to "-...","پ" to ".--.","ت" to "-","ث" to "-.-..","ج" to ".---","چ" to "---.","ح" to "....","خ" to "-.-.-","د" to "-..","ذ" to "--..","ر" to ".-.","ز" to "--..","ژ" to "--.-","س" to "...","ش" to "----","ص" to "-..-.","ض" to "...-.","ط" to ".-.-","ظ" to "-.--.","ع" to ".-.-.","غ" to "..--","ف" to "..-.","ق" to "--.-","ک" to "-.-","گ" to "--.","ل" to ".-..","م" to "--","ن" to "-.","و" to ".--","ه" to ".","ی" to "..",
        "۰" to "-----","۱" to ".----","۲" to "..---","۳" to "...--","۴" to "....-","۵" to ".....","۶" to "-....","۷" to "--...","۸" to "---..","۹" to "----."
    )
    val WABUN=mapOf("イ" to ".-","ロ" to ".-.-","ハ" to "-...","ニ" to "-.-.","ホ" to "-..","ヘ" to ".","ト" to "..-..","チ" to "..-.","リ" to "--.","ヌ" to "....","ル" to "-.--.","ヲ" to ".---","ワ" to "-.-","カ" to ".-..","ヨ" to "--","タ" to "-.","レ" to "---","ソ" to "---.","ツ" to ".--.","ネ" to "--.-","ナ" to ".-.","ラ" to "...","ム" to "-","ウ" to "..-","ヰ" to ".-..-","ノ" to "..--","オ" to ".-...","ク" to "...-","ヤ" to ".--","マ" to "-..-","ケ" to "-.--","フ" to "--..","コ" to "----","エ" to "-.---","テ" to ".-.--","ア" to "--.--","サ" to "-.-.-","キ" to "-.-..","ユ" to "-..--","メ" to "-...-","ミ" to "..-.-","シ" to "--.-.","ヱ" to ".--..","ヒ" to "--..-","モ" to "-..-.","セ" to ".---.","ス" to "---.-","ン" to ".-.-.","゛" to "..","゜" to "..--.","ー" to ".--.-")
    val SKATS=mapOf("ㄱ" to ".-..","ㄴ" to "-.","ㄷ" to ".","ㄹ" to "..-.","ㅁ" to ".--","ㅂ" to "--.","ㅅ" to "-","ㅇ" to "--","ㅈ" to "-...","ㅊ" to ".-","ㅋ" to "--..","ㅌ" to "...","ㅍ" to "---","ㅎ" to ".---","ㅏ" to "-.-","ㅑ" to "..","ㅓ" to "....","ㅕ" to "..-","ㅗ" to "-..","ㅛ" to "-.--","ㅜ" to ".--.","ㅠ" to ".-.","ㅡ" to "-.-.","ㅣ" to "-..-")
}

class Hamming74Converter:Converter { override val meta=ConverterMeta("hamming74","همینگ (7,4)","Hamming (7,4)",Category.ERROR_CORRECTION); override fun encode(input:String):ConversionResult {val bits=input.filterNot{it.isWhitespace()};if(bits.isEmpty()||bits.any{it!='0'&&it!='1'}||bits.length%4!=0)return ConversionResult.Error("ورودی باید بلوک‌های 4 بیتی باشد.");return ConversionResult.Success(bits.chunked(4).joinToString(" "){enc4(it)})}; private fun enc4(s:String):String{val d1=s[0]-'0';val d2=s[1]-'0';val d3=s[2]-'0';val d4=s[3]-'0';val p1=d1 xor d2 xor d4;val p2=d1 xor d3 xor d4;val p4=d2 xor d3 xor d4;return "$p1$p2$d1$p4$d2$d3$d4"}; override fun decode(input:String):ConversionResult {val toks=input.trim().split(Regex("\\s+"));if(toks.isEmpty())return ConversionResult.Error("ورودی خالی است.");val out=StringBuilder();for(t in toks){if(t.length!=7||t.any{it!='0'&&it!='1'})return ConversionResult.Error("هر بلوک باید 7 بیت باشد.");val a=t.map{it-'0'}.toMutableList();val s1=a[0] xor a[2] xor a[4] xor a[6];val s2=a[1] xor a[2] xor a[5] xor a[6];val s4=a[3] xor a[4] xor a[5] xor a[6];val pos=s1+2*s2+4*s4;if(pos in 1..7)a[pos-1]=a[pos-1] xor 1;out.append("${a[2]}${a[4]}${a[5]}${a[6]}")};return ConversionResult.Success(out.toString())} }

data class MedicalTerm(val id:String,val persian:String,val english:String,val latin:String,val category:String,val aliases:List<String> = emptyList(),val definition:String="")
class MedicalConverter(private val target:String):Converter { override val meta=ConverterMeta("medical_$target",if(target=="latin")"پزشکی → لاتین" else "پزشکی → فارسی/انگلیسی","Medical terminology",Category.MEDICAL,true,false); override fun encode(input:String):ConversionResult {val q=normalize(input);val t=MedicalDictionary.terms.firstOrNull{listOf(it.persian,it.english,it.latin).plus(it.aliases).any{v->normalize(v)==q}}?:return ConversionResult.Error("معادل تأییدشده‌ای در واژه‌نامه محلی پیدا نشد.");return ConversionResult.Success(when(target){"latin"->t.latin;"english"->t.english;"persian"->t.persian;else->"${t.persian} | ${t.english} | ${t.latin}"})}; override fun decode(input:String)=ConversionResult.Error("برای واژه‌نامه، جهت جستجو از انتخاب مقصد تعیین می‌شود."); private fun normalize(s:String)=s.trim().lowercase().replace('ي','ی').replace('ك','ک').replace("‌"," ").replace(Regex("\\s+")," ") }
object MedicalDictionary { val terms=listOf(
    MedicalTerm("heart","قلب","heart","cor","cardiovascular",listOf("cardiac organ")),
    MedicalTerm("brain","مغز","brain","encephalon","nervous system"),
    MedicalTerm("liver","کبد","liver","hepar","digestive"),
    MedicalTerm("kidney","کلیه","kidney","ren","urinary",listOf("renal organ")),
    MedicalTerm("lung","ریه","lung","pulmo","respiratory"),
    MedicalTerm("stomach","معده","stomach","gaster","digestive"),
    MedicalTerm("femur","استخوان ران","femur","femur","skeletal",listOf("thigh bone")),
    MedicalTerm("tibia","درشت‌نی","tibia","tibia","skeletal"),
    MedicalTerm("fibula","نازک‌نی","fibula","fibula","skeletal"),
    MedicalTerm("humerus","استخوان بازو","humerus","humerus","skeletal"),
    MedicalTerm("radius","زند زبرین","radius","radius","skeletal"),
    MedicalTerm("ulna","زند زیرین","ulna","ulna","skeletal"),
    MedicalTerm("skull","جمجمه","skull","cranium","skeletal"),
    MedicalTerm("spine","ستون مهره‌ها","vertebral column","columna vertebralis","skeletal",listOf("spine")),
    MedicalTerm("esophagus","مری","esophagus","oesophagus","digestive"),
    MedicalTerm("trachea","نای","trachea","trachea","respiratory"),
    MedicalTerm("pancreas","لوزالمعده","pancreas","pancreas","digestive"),
    MedicalTerm("spleen","طحال","spleen","splen","lymphatic"),
    MedicalTerm("bladder","مثانه","urinary bladder","vesica urinaria","urinary"),
    MedicalTerm("uterus","رحم","uterus","uterus","reproductive")
) }

fun decodeBytes(b:ByteArray?):ConversionResult { if(b==null)return ConversionResult.Error("ورودی encoded نامعتبر است."); return try { val d=Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);ConversionResult.Success(d.decode(ByteBuffer.wrap(b)).toString()) }catch(_:Exception){ConversionResult.Error("خروجی بایت، UTF-8 معتبر نیست.")} }

object ConverterRegistry {
    val all:List<Converter> = listOf(
        ByteRadixConverter(2,8,ConverterMeta("binary","باینری","Binary",Category.BYTES)),
        ByteRadixConverter(8,3,ConverterMeta("octal","اکتال","Octal",Category.BYTES)),
        ByteRadixConverter(10,3,ConverterMeta("decimal","دهدهی","Decimal bytes",Category.BYTES)),
        ByteRadixConverter(16,2,ConverterMeta("hex","هگزادسیمال","Hexadecimal",Category.BYTES)),
        Base32Converter(),
        Base64Converter(false,true,ConverterMeta("base64_std","بیس۶۴ استاندارد","Standard Base64",Category.BASE)),
        Base64Converter(true,true,ConverterMeta("base64_url","بیس۶۴ URL-safe","Base64URL",Category.BASE)),
        Base64Converter(false,false,ConverterMeta("base64_nopad","بیس۶۴ بدون Padding","Base64 without padding",Category.BASE)),
        Ascii85Converter(), ImapModifiedUtf7Converter(), AsciiConverter(), UnicodeConverter(),
        UtfConverter(UtfKind.UTF8,ConverterMeta("utf8","UTF-8","UTF-8",Category.UTF)),
        UtfConverter(UtfKind.UTF16,ConverterMeta("utf16","UTF-16","UTF-16 (BOM)",Category.UTF)),
        UtfConverter(UtfKind.UTF16BE,ConverterMeta("utf16be","UTF-16BE","UTF-16BE",Category.UTF)),
        UtfConverter(UtfKind.UTF16LE,ConverterMeta("utf16le","UTF-16LE","UTF-16LE",Category.UTF)),
        UtfConverter(UtfKind.UTF32BE,ConverterMeta("utf32be","UTF-32BE","UTF-32BE",Category.UTF)),
        UtfConverter(UtfKind.UTF32LE,ConverterMeta("utf32le","UTF-32LE","UTF-32LE",Category.UTF)),
        UtfConverter(UtfKind.UTF7,ConverterMeta("utf7","UTF-7 (Legacy)","UTF-7 (Legacy)",Category.UTF)),
        MorseConverter(ConverterMeta("morse_intl","مورس بین‌المللی","International Morse",Category.MORSE),MorseTables.INTERNATIONAL),
        MorseConverter(ConverterMeta("morse_persian","مورس فارسی","Persian Morse",Category.MORSE),MorseTables.PERSIAN),
        MorseConverter(ConverterMeta("morse_wabun","وابون ژاپنی","Japanese Wabun",Category.MORSE),MorseTables.WABUN),
        MorseConverter(ConverterMeta("morse_skats","SKATS کره‌ای","Korean SKATS",Category.MORSE),MorseTables.SKATS),
        Hamming74Converter(), MedicalConverter("all"), MedicalConverter("persian"), MedicalConverter("english"), MedicalConverter("latin")
    )
    fun byId(id:String)=all.firstOrNull{it.meta.id==id}
}
