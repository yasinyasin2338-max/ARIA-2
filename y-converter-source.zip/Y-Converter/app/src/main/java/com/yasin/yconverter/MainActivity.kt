package com.yasin.yconverter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.yasin.yconverter.core.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity:ComponentActivity(){private val vm by viewModels<MainViewModel>();override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);enableEdgeToEdge();setContent{YTheme{YScreen(vm)}}}}
@Composable fun YTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=darkColorScheme(),content=content)}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun YScreen(vm:MainViewModel){val s by vm.state.collectAsStateWithLifecycle();var sheet by remember{mutableStateOf(false)};val clip=LocalClipboardManager.current;val snack=remember{SnackbarHostState()};val scope=rememberCoroutineScope();Scaffold(snackbarHost={SnackbarHost(snack)}){pad->LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Y Converter",style=MaterialTheme.typography.headlineMedium)};item{OutlinedTextField(value=s.inputText,onValueChange=vm::setInput,modifier=Modifier.fillMaxWidth().heightIn(min=150.dp),label={Text("متن فارسی یا انگلیسی را وارد کنید…")})};item{Button(onClick={sheet=true},modifier=Modifier.fillMaxWidth()){val m=ConverterRegistry.byId(s.selectedModeId)?.meta;Text("${m?.fa} • ${m?.en}")}};item{SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()){SegmentedButton(selected=s.operation==Operation.ENCODE,onClick={vm.setOperation(Operation.ENCODE)},shape=SegmentedButtonDefaults.itemShape(0,2)){Text("Encode")};SegmentedButton(selected=s.operation==Operation.DECODE,onClick={vm.setOperation(Operation.DECODE)},shape=SegmentedButtonDefaults.itemShape(1,2)){Text("Decode")}}};item{Button(onClick=vm::convert,enabled=!s.isProcessing,modifier=Modifier.fillMaxWidth()){if(s.isProcessing)CircularProgressIndicator(Modifier.size(20.dp)) else Text("تبدیل")}};s.errorMessage?.let{item{Text(it,color=MaterialTheme.colorScheme.error)}};item{Card(Modifier.fillMaxWidth()){Text(if(s.outputText.isBlank())"نتیجه اینجا نمایش داده می‌شود." else s.outputText,Modifier.padding(16.dp))}};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={clip.setText(AnnotatedString(s.outputText));scope.launch{snack.showSnackbar("کپی شد")}},enabled=s.canCopy){Text("کپی")};OutlinedButton(onClick=vm::clear){Text("پاک کردن")}}}};if(sheet)ModalBottomSheet(onDismissRequest={sheet=false}){LazyColumn(Modifier.fillMaxWidth().padding(bottom=32.dp)){Category.entries.forEach{cat->item{Text(cat.fa,style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(16.dp,12.dp,16.dp,4.dp))};items(ConverterRegistry.all.filter{it.meta.category==cat}){c->ListItem(headlineContent={Text(c.meta.fa)},supportingContent={Text(c.meta.en)},modifier=Modifier.fillMaxWidth());HorizontalDivider();TextButton(onClick={vm.setMode(c.meta.id);sheet=false},modifier=Modifier.fillMaxWidth()){Text("انتخاب ${c.meta.fa}")}}}}}}
