package com.yasin.yconverter
import com.yasin.yconverter.core.*
import org.junit.Assert.*
import org.junit.Test
class CoreConvertersTest {
    private val vectors=listOf("Hello","سلام","Hello سلام ۱۲3","😀","نیم‌فاصله‌دار","line1\nline2","")
    @Test fun reversibleCore(){ val ids=listOf("binary","octal","decimal","hex","base32","base64_std","base64_url","base64_nopad","ascii85","utf8","utf16","utf16be","utf16le","utf32be","utf32le","utf7","imap_mod_utf7"); for(id in ids){val c=ConverterRegistry.byId(id)!!;for(v in vectors){val e=c.encode(v) as ConversionResult.Success;val d=c.decode(e.value);assertEquals("$id / $v",v,(d as ConversionResult.Success).value)}} }
    @Test fun unicodeEmoji(){val c=UnicodeConverter();val e=c.encode("A😀") as ConversionResult.Success;assertEquals("U+0041 U+01F600",e.value);assertEquals("A😀",(c.decode(e.value) as ConversionResult.Success).value)}
    @Test fun asciiRejectsPersian(){assertTrue(AsciiConverter().encode("سلام") is ConversionResult.Error)}
    @Test fun hammingCorrectsSingleBit(){val c=Hamming74Converter();val e=(c.encode("1011") as ConversionResult.Success).value;val x=e.toCharArray();x[2]=if(x[2]=='0')'1' else '0';assertEquals("1011",(c.decode(String(x)) as ConversionResult.Success).value)}
    @Test fun morseRoundTrip(){val c=ConverterRegistry.byId("morse_intl")!!;val e=c.encode("SOS 123") as ConversionResult.Success;assertEquals("SOS 123",(c.decode(e.value) as ConversionResult.Success).value)}
    @Test fun medical(){val c=ConverterRegistry.byId("medical_latin")!!;assertEquals("cor",(c.encode("قلب") as ConversionResult.Success).value);assertTrue(c.encode("واژه ناشناخته") is ConversionResult.Error)}
}
