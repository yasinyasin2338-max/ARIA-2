package com.yasin.yconverter
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
class MainUiTest { @get:Rule val rule=createAndroidComposeRule<MainActivity>(); @Test fun mainFlow(){rule.onNodeWithText("متن فارسی یا انگلیسی را وارد کنید…").performTextInput("سلام");rule.onNodeWithText("تبدیل").performClick();rule.onNodeWithText("کپی").assertIsEnabled();rule.onNodeWithText("پاک کردن").performClick()} }
