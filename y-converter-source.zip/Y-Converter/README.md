# Y Converter — Android

اپلیکیشن آفلاین تبدیل متن/بایت و واژه‌نامه پزشکی با Kotlin + Jetpack Compose.

## قابلیت‌های V1 موجود در سورس
- Binary / Octal / Decimal / Hex به‌صورت نمایش byteهای UTF‑8 و round-trip
- Base32 (RFC 4648)، Standard Base64، Base64URL، padded/unpadded
- ASCII85 (Base85 variant صریح)
- ASCII و Unicode code points
- UTF-8 / UTF-16(BOM) / UTF-16BE / UTF-16LE / UTF-32BE / UTF-32LE / UTF-7 Legacy
- IMAP Modified UTF-7
- International Morse، Persian Morse، Wabun، Korean SKATS (data-driven)
- Hamming(7,4) با اصلاح تک‌بیت
- واژه‌نامه محلی پزشکی/آناتومی سه‌زبانه (نمونه V1؛ محدود و صریحاً غیرجامع)
- UI فارسی، Dark theme، Copy/Clear، پردازش background، بدون INTERNET permission

## نکته درباره موارد هنوز غیرجامع
Arabic/Cyrillic/Greek/Hebrew Morse تا زمان اضافه‌شدن table مستند و QA شده وارد registry نشده‌اند؛ Persian Morse اضافه شده ولی به‌علت الگوهای تکراری مستند، decode بعضی حروف ذاتاً مبهم است؛ نام بدون mapping معتبر اضافه نشده است. bcrypt/crypt-style Base64 نیز به دلیل semantics مخصوص خودشان با substitution ساده جعل نشده‌اند. واژه‌نامه پزشکی V1 محدود است و ادعای پوشش کامل Terminologia Anatomica ندارد.

## Build
نسخه‌های قفل‌شده: AGP 9.4.0، Gradle 9.6.0، Kotlin 2.4.20، Compose BOM 2026.09.00.

```bash
gradle testDebugUnitTest
gradle lintDebug
gradle assembleDebug
```

GitHub Actions فایل `.github/workflows/android.yml` همین مراحل را اجرا می‌کند و APK دیباگ را Artifact می‌کند.

## نصب
APK خروجی `app/build/outputs/apk/debug/app-debug.apk` را روی Android باز کنید و در صورت نیاز اجازه Install unknown apps را برای برنامه‌ای که APK را باز می‌کند فعال کنید.

## حریم خصوصی
Manifest هیچ INTERNET permission ندارد؛ conversionها و lookupهای V1 local هستند.
