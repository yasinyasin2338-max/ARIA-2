# Y Converter — Build/Test Status

Date: 2026-09-22

## Verified in this environment
- Pure Kotlin converter core compiled successfully with local `kotlinc`.
- 119 encode→decode round-trip checks passed across Binary/Octal/Decimal/Hex, Base32, Base64 variants, ASCII85, UTF-8/16/32/7 and IMAP Modified UTF-7 using English, Persian, mixed text, emoji, ZWNJ, newline and empty text.
- Unicode supplementary emoji check passed.
- ASCII rejection of Persian input passed.
- Hamming(7,4) single-bit correction check passed.
- International Morse round-trip passed.
- Persian Morse encode smoke test passed.
- Medical Latin lookup smoke test passed.

## Not verified here
- Full Android Gradle build, lint and APK generation were NOT executed because the current execution container has Java but no Android SDK/Gradle installation and its shell has no outbound DNS/network access to download them.
- Instrumented/UI tests were therefore not executed.
- APK installability on a physical device/emulator is not verified.

## GitHub
A GitHub Actions workflow is included. The connected GitHub tooling available in this session can write to existing repositories but does not expose repository creation, so no unrelated existing repository was modified just to run CI.

## Known V1 limitations
- Arabic/Cyrillic/Greek/Hebrew Morse tables are not yet bundled; no fake mappings were added.
- Persian Morse includes documented duplicate patterns, so some Morse→Persian decoding is intrinsically ambiguous.
- bcrypt/crypt-style Base64 variants are not faked with alphabet substitution; only IMAP Modified UTF-7 is implemented under modified variants.
- Medical dictionary is a small local V1 seed, not a complete Terminologia Anatomica database.
